﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zhu.Yuheng.RRCAGApp
{
    public class Fragrances
    {
        public enum FieldIndex
        {
            FragrancesType,
            Price
        }
    }
}
